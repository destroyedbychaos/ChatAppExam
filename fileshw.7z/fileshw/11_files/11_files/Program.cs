﻿using System.Text;

namespace _11_files
{
    internal class Program
    {
        static async Task<bool> WriteToFileAsync(string path, string text, Encoding? encoding = null, bool createFile = true)
        {
            //if (encoding == null)
            //{
            //    encoding = Encoding.Default;
            //}
            encoding ??= Encoding.Default;

            byte[] data = encoding.GetBytes(text);
            return await WriteToFileAsync(path, data, createFile);
        }

        static async Task<bool> WriteToFileAsync(string path, byte[] data, bool createFile = true)
        {
            FileMode mode = createFile ? FileMode.OpenOrCreate : FileMode.Open;

            try
            {
                using (var fileStream = new FileStream(path, mode))
                {
                    await fileStream.WriteAsync(data);
                    return true;
                }
            }
            catch (Exception ex)
            {
                await Console.Out.WriteLineAsync(ex.Message);
                return false;
            }
        }

        static void Main(string[] args)
        {
            // Робота з файлами

            // Stream базовий клас для роботи з потоками


            // FileStream

            // запис у файл
            //using (var fs = new FileStream("filestream.txt", 
            //    FileMode.OpenOrCreate, 
            //    FileAccess.ReadWrite, 
            //    FileShare.ReadWrite))
            //{
            //    var message = Encoding.Default.GetBytes("Text file message");

            //    fs.Write(message);
            //}

            // читання з файлу
            //try
            //{
            //    using (var fs = new FileStream("filestream.txt",
            //    FileMode.Open))
            //    {
            //        byte[] buffer = new byte[fs.Length]; // fs.Length розмір файлу
            //        fs.Read(buffer);

            //        string text = Encoding.Default.GetString(buffer);
            //        Console.WriteLine(text);

            //        fs.Close(); // не потрібно писати якщо використовуєте using
            //    }
            //}
            //catch (FileNotFoundException)
            //{
            //    Console.WriteLine("filestream.txt not found");
            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine(ex.Message);
            //}



            // Робота зі своїм методом
            //WriteToFileAsync("testasync.txt", "Good read method").Wait();




            // StreamWriter/Reader


            //using (var sw = new StreamWriter("StreamWriter.txt"))
            //{
            //    sw.Write("Lorem Ipsum is simply dummy text of the printing and typesetting industry.");
            //}

            //using (Stream stream = new FileStream("StreamWriter.txt", FileMode.Open))
            //{
            //    using (var sr = new StreamReader(stream))
            //    {
            //        // sr.BaseStream // повертає stream

            //        string text = sr.ReadToEnd();
            //        Console.WriteLine(text);
            //    }
            //}




            // BinaryWriter/Reader

            using(Stream stream = new FileStream("binary.bin", FileMode.OpenOrCreate))
            {
                using (var bw = new BinaryWriter(stream))
                {
                    bw.Write(50);
                    bw.Write(2.4f);
                }
            }

            using (Stream stream = new FileStream("binary.bin", FileMode.Open))
            {
                using (var br = new BinaryReader(stream))
                {
                    int i = br.ReadInt32();
                    float f = br.ReadSingle();
                }
            }

            //using (Stream stream = new FileStream("sfml_template (2).zip", FileMode.Open))
            //{
            //    using (var br = new BinaryReader(stream))
            //    {
            //        string bytes = Encoding.Default.GetString(br.ReadBytes((int)br.BaseStream.Length));

            //        Console.WriteLine(bytes);
            //    }
            //}
        }
    }
}
