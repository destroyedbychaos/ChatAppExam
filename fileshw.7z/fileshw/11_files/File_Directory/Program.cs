﻿using System.Text;

namespace File_Directory
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Path.Combine(root, filename); -> об'єднує шляхи


                                // Directory
            //string curDir = Directory.GetCurrentDirectory(); // де знаходить exe файл
            //string newDir = Path.Combine(curDir, "data");
            //Directory.CreateDirectory(newDir);
            //string root = Directory.GetDirectoryRoot(newDir); // корінь шляху
            //Console.WriteLine(root);



            //string[] files = Directory.GetFiles(curDir);

            //foreach (var file in files)
            //{
            //    Console.WriteLine(file);
            //}

                            // DirectoryInfo
            //DirectoryInfo directoryInfo = new DirectoryInfo(curDir);
            //Console.WriteLine(directoryInfo.CreationTime);
            //Console.WriteLine(directoryInfo.Name);
            //Console.WriteLine(directoryInfo.LastAccessTime);



            // File
            //string curDir = Directory.GetCurrentDirectory();
            //string workDir = Path.Combine(curDir, "data");
            //string filePath = Path.Combine(workDir, "data.txt");

            //if(File.Exists(filePath))
            //{
            //    File.Delete(filePath);
            //}

            //var stream = File.Create(filePath);

            //string text = "Hello, this file class";
            //byte[] data = Encoding.UTF8.GetBytes(text);

            //stream.Write(data);

            //stream.Dispose();


            // FileInfo
            //FileInfo fileInfo = new FileInfo(filePath);

            //Console.WriteLine(fileInfo.Extension);
            //Console.WriteLine(fileInfo.Name);
            //Console.WriteLine(fileInfo.FullName);


            FileManager fileManager = new FileManager("C:/Users/hp/testsubjects");


            FileManagerUI ui = new FileManagerUI(fileManager);
            ui.Show();

            while(true)
            {
                var key = Console.ReadKey();

                if(key.Key == ConsoleKey.UpArrow)
                {
                    ui.Up();
                }
                else if(key.Key == ConsoleKey.DownArrow)
                {
                    ui.Down();
                }
                else if(key.Key == ConsoleKey.LeftArrow)
                {
                    ui.Back();
                }
                else if(key.Key == ConsoleKey.Backspace)
                {
                    ui.Delete();
                }
                else if(key.Key == ConsoleKey.Enter || key.Key == ConsoleKey.RightArrow)
                {
                    ui.OpenFolder();
                }
            }
        }
    }
}
