﻿using System.Diagnostics;

namespace File_Directory
{
    public class FileManager
    {
        private readonly string root;
        public string CurrentDir { get; private set; }

        public FileManager()
        {
            root = Directory.GetDirectoryRoot(Directory.GetCurrentDirectory());
            CurrentDir = root;
        }

        public FileManager(string currentDir)
        {
            if (!Directory.Exists(currentDir))
            {
                throw new ArgumentException("dir not found");
            }

            root = Directory.GetDirectoryRoot(currentDir);
            CurrentDir = currentDir;
        }

        public void NextFolder(string name)
        {
            string nextPath = Path.Combine(CurrentDir, name);

            if(Directory.Exists(nextPath))
            {
                CurrentDir = nextPath;
            }
            else if (File.Exists(nextPath))
            {
                ProcessStartInfo startInfo = new ProcessStartInfo(nextPath);
                startInfo.UseShellExecute = true;
                Process.Start(startInfo);
            }
            else
            {
                throw new DirectoryNotFoundException();
            }
        }

        public void PrevFolder()
        {
            DirectoryInfo prevPath = Directory.GetParent(CurrentDir);

            if (prevPath != null)
            {
                CurrentDir = prevPath.FullName;
            }
            else
            {
                throw new DirectoryNotFoundException();
            }
        }

        public void DeleteItem(string DelDir)
        {

            Console.WriteLine("are you sure you want to delete it? y/n");
            string response = Console.ReadLine();

            try
            {
                if(response == "y")
                {
                    if (Directory.Exists(DelDir))
                    {
                        Directory.Delete(DelDir, true);
                    }
                    else if(File.Exists(DelDir))
                    {
                        File.Delete(DelDir);
                    }
                }
                else
                {
                    Console.WriteLine("directory not deleted");
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public List<string> GetDirectoriesName()
        {
            var dirs = Directory.GetDirectories(CurrentDir);
            List<string> directories = new List<string>();

            foreach (var dir in dirs)
            {
                DirectoryInfo info = new DirectoryInfo(dir);
                directories.Add(info.Name);
            }

            return directories;   
        }

        public List<string> GetFilesName()
        {
            var filesName = Directory.GetFiles(CurrentDir);
            List<string> files = new List<string>();

            foreach (var file in filesName)
            {
                FileInfo info = new FileInfo(file);
                files.Add(info.Name);
            }

            return files;
        }

        public List<string> GetItemsName()
        {
            var dirs = GetDirectoriesName();
            var files = GetFilesName();
            var res = new List<string>(dirs);
            res.AddRange(files);

            return res;
        }

        public int ItemsCount()
        {
            return GetItemsName().Count;
        }
    }
}
