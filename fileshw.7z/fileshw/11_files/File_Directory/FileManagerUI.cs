﻿namespace File_Directory
{
    public class FileManagerUI
    {
        private readonly FileManager _fileManager;
        private int selectedIndex = 0;
        private const ConsoleColor selectedColor = ConsoleColor.Green;
        private const ConsoleColor unselectedColor = ConsoleColor.White;
        private ConsoleColor defaultColor = Console.ForegroundColor;

        public FileManagerUI(string currentDir)
        {
            _fileManager = new FileManager(currentDir);   
        }

        public FileManagerUI()
        {
            _fileManager = new FileManager();
        }

        public FileManagerUI(FileManager fileManager)
        {
            _fileManager = fileManager;
        }

        public void Down()
        {
            if(selectedIndex < _fileManager.ItemsCount() - 1)
            {
                selectedIndex++;
            }

            Update();
        }

        public void Up()
        {
            if(selectedIndex > 0)
            {
                selectedIndex--;
            }

            Update();
        }

        public void Back()
        {
            _fileManager.PrevFolder();
            Update();
        }

        public void Delete()
        {
            if(_fileManager.GetItemsName()[selectedIndex] != null)
            {
                var itemName = _fileManager.GetItemsName()[selectedIndex];
                var itemPath = Path.Combine(_fileManager.CurrentDir, itemName);
                _fileManager.DeleteItem(itemPath);
                selectedIndex = 0;
                Update();
            }
            else
            {
                throw new ArgumentException("nothing to delete");
            }
        }

        public void Update()
        {
            Console.Clear();
            Show();
        }

        public void Show()
        {
            var res = _fileManager.GetItemsName();

            for (int i = 0; i < res.Count; i++)
            {
                Console.ForegroundColor = i == selectedIndex ? selectedColor : unselectedColor;
                string pointer = i == selectedIndex ? "-> " : "   ";

                Console.WriteLine(pointer + res[i]);

            }
            Console.ForegroundColor = defaultColor;
        }

        public void OpenFolder()
        {
            var dir = _fileManager.GetItemsName()[selectedIndex];
            _fileManager.NextFolder(dir);
            selectedIndex = 0;
            Update();
        }
    }
}
